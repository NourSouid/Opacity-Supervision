// version 0.1
#include <time.h>
#include <iostream>
#include <string>
#include<stdio.h>
#include<fstream>
using namespace std;
#include "bdd.h"
#include "fdd.h"
#include "Net.h"
#include "RdPBDD.h"
#include "math.h"
//int Formula_transitions(const char * f, Set_mot& formula_trans, net Rv) ;
double getTime() {
	return (double) clock() / (double) CLOCKS_PER_SEC;
}
int Menu() {
	int choix;
	cout << "\t\t______________________________________________" << endl;
	cout << "\t\t|                                            |" << endl;
	cout << "\t\t|        OBSERVATION GRAPHE TOOL             |" << endl;
	cout << "\t\t______________________________________________\n\n" << endl;
	cout
			<< "\tConstruction de l'espace d'etats accessible avec OBDDs            : 1\n"
			<< endl;
	cout
			<< "\tConstruction du graphe d'observation avec Canonize Dichotomique   : 2\n"
			<< endl;
	cout
			<< "\tProduit synchronise a la volee de n graphes d'observations        : 3\n"
			<< endl;
	cout
			<< "\tProduit synchronise canonise de n graphes d'observations          : 4\n"
			<< endl;
	cout << "\tQuitter l'outil : 0" << endl;
	cin >> choix;
	return choix;
}

void reordering(int nbvar) {

	// all the variables belong to a main block
	bdd_varblockall();
	// to each fdd variable corresponds a block
	for (int i = 0; i < nbvar; i++)
		fdd_intaddvarblock(i, i, BDD_REORDER_FIXED);

	bdd_autoreorder(BDD_REORDER_SIFT);

	bdd_reorder_verbose(2);
}

//*************************************************
int frequency_of_primes (int n) {
  int i,j;
  int freq=n-1;
  for (i=2; i<=n; ++i) for (j=sqrt(i);j>1;--j) if (i%j==0) {--freq; break;}
  return freq;
}

/***********************************************/
int main(int argc, char** argv) {
	/**/
	freopen("C:/Users/nours/OneDrive/Desktop/Amina/examples/alpha-beta/QSOG-Results.txt", "w+", stdout);
	cout<<"Nour Workspace"<<endl;
	/**/
	cout << "**********************************************************"
			<< endl;
	cout << "**********************************************************"
			<< endl;
	cout << "                  Opacity verifier                " << endl;
	cout << "**********************************************************"
			<< endl;
	cout << "**********************************************************"
			<< endl;
/*
	double time;

		  time = getTime();
		 cout<<"time= "<<time<<endl;
*/
	clock_t t;
	  int f;
	  t = clock();
	 // printf ("Calculating...\n");
	  f = frequency_of_primes (99999);
	//  printf ("The number of primes lower than 100,000 is: %d\n",f);

	int b = 32;
	if (argc < 3)
		return 0;
	char Obs[100] = "";	//obsevables
	char Int[100] = "";	//secrets
	char Int1[100] = "";	//opacity choice

	if (argc > 3)
		//  cout<<"argv[2] is:"<<argv[2]<<endl;//
		strcpy(Obs, argv[2]);
	//  cout<<"obs is:"<<Obs<<endl;
	// cout<<"argv[2] is:"<<argv[1]<<endl;
	// cout<<"argv[2] is:"<<argv[2]<<endl;
	//  cout<<"argv[3] is:"<<argv[3]<<endl;
	if (argc > 4)
		strcpy(Int, argv[3]);
	strcpy(Int1, argv[4]);
	//   cout<<"argv[4] is:"<<argv[4]<<endl;
	//  cout<<"argv[5] is:"<<argv[5]<<endl;
	b = atoi(argv[argc - 1]); //maximal marking
	// cout<<"b is:"<<b<<endl;

	//stdout = freopen("/home/amina/workspace/ObsGraphTool/examples/sys/sys-1-events.txt", "w+", stdout);
	cout << "Example File: " << argv[1] << endl;

	//cout<<"<Alphabet>"<<endl;
	net R(argv[1], Obs, Int, Int1);	//parse pnml file and create petri net (nodes)

	//  cout<<"came back from net"<<endl; //added by me

//	double a, d, tps;

	//  a = getTime();
	//  cout<<"time= "<<a<<endl;

	RdPBDD DR(R, b); //create bdd representing the secret
					 //fill vars of observables, nonobservables and secret
					 // creates the bdd representing the secret
	//cout<<" </Alphabet>"<<endl;
	//return 0;
	MDGraph g; //was not commented
			   //aggregate sog?
	//visualisation and creation of bdd (sog)
	// no print when garbage collection operates
	bdd_gbc_hook(NULL); //was not comented
	// 	reordering(R.places.size()*2);
	// 	bdd_reorder(BDD_REORDER_RANDOM);
//	d = getTime();
	//  cout<<"time1: "<<d<<endl;
	DR.compute_canonical_deterministic_graph_Opt(g); //was not commented
/*	d = getTime();
	 cout<<"time2: "<<d<<endl;
	tps = d - time;
	cout << " Construction time: " << tps << endl;*/
	t = clock() - t;
		  printf ("construction time: (%f seconds).\n",t,((float)t)/CLOCKS_PER_SEC);
	g.printCompleteInformation(); //was not commented


//another cp file method
	/*std::ifstream  src("Sec_cp.txt", std::ios::binary);
	std::ofstream  dst("Secrets.txt",   std::ios::binary);

	dst << src.rdbuf();*/

	//fix Secrets.txt code
/*			        std::ifstream fin( "Sec_cp.txt" ) ;
				    std::ofstream fout( "Secrets.txt" ) ;
				    std::string line ;
				    while( std::getline( fin, line, '\n' ) ) fout << line << '\n' ;
				    cout<<line<<'\n';
				    fin.close();
				    fout.close();*/
	return 0;
}
