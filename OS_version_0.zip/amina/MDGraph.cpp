
/********              Graph.cpp     *******/
#include"MDGraph.h"
#include"Net.h"
/*#include <conio>*/

bdd * Tab;

/********* setInitialState    *****/


void MDGraph::setInitialState(Class_Of_State *c)
{
	//cout << " initialisation  avec classe"<<  c->class_state << endl;

	currentstate=initialstate=c;
}
/*----------------------find()----------------*/
//find gnode with id equals c
//remember that c is initial state
Class_Of_State * MDGraph::find(Class_Of_State* c) //c is a pointer?
{
//MetaGrapheNodes = vector of Class_Of_State?
	for(MetaGrapheNodes::const_iterator i=GONodes.begin();!(i==GONodes.end());i++)
//from i=first value of GONodes (MetaGrapheNodes) till last, i++
    if(c->class_state.id()==(*i)->class_state.id())
    	//if c.class_state.id= *i.class_state.id
			return *i;

	//else	statement
	return NULL;
}


/*----------------------insert() ------------*/
void MDGraph::insert(Class_Of_State *c)
{

	c->Visited=false;
//	c=c & fdd_ithset(2);
//	cout << c<<endl ;

	this->GONodes.push_back(c);
	nbAggregates++;
}

/*----------------------NbBddNod()------------------------*/
int MDGraph::NbBddNode(Class_Of_State * S, size_t& nb)
{
	//cout << "appele de la methode NbBddNOde "<< endl;

	if(S->Visited==false)
	{
		//cout<<"insertion du meta etat numero :"<<nb<<"son id est :"<<S->class_state.id()<<endl;
		//cout<<"sa taille est :"<<bdd_nodecount(S->class_state)<<" noeuds \n";
		Tab[nb-1]=S->class_state;
		S->Visited=true;
		int bddnode=bdd_nodecount(S->class_state);
		//cout << " le bdd node count is "<< bddnode ;
		int size_succ=0;
		for(Edges::const_iterator i=S->Successors.begin();!(i==S->Successors.end());i++)
		{
			if((*i).first->Visited==false)
			{
				nb++;
				size_succ+=NbBddNode((*i).first,nb);
			}
		}
		return size_succ+bddnode;
		
	}
	else
		return 0;
}

/*----------------------Visualisation du graphe------------------------*/
void MDGraph::printCompleteInformation()
{

	cout<<" \n";
	cout << "print complete information: "<<endl;
	cout << "\n\nGRAPH SIZE : \n";
	//cout<< "\n\tNB MARKING : "<< nbMarking;
	cout<< "\n\tNB NODES : "<< nbAggregates;
	cout<<"\n\tNB ARCS : " <<nbArcs<<endl;
	cout<<" \n\nCOMPLETE INFORMATION Only when your system is opaque ?(y/n)\n";
	char c;
    cin>>c;
	//InitVisit(initialstate,n);
	Tab=new bdd[(int)nbAggregates];
	size_t n=1;
	cout<<"NB BDD NODE : "<<NbBddNode(initialstate,n)<<endl;
	NbBddNode(initialstate,n);
	//cout<<"NB BDD NODE : "<<bdd_anodecount(Tab,(int)nbStates)<<endl;
	//cout<<"Shared Nodes : "<<bdd_anodecount(Tab,nbStates)<<endl;
	InitVisit(initialstate,1);
	//int toto;cin>>toto;
	//bdd Union=UnionMetaState(initialstate,1);
	//cout<<"a titre indicatif taille de l'union : "<<bdd_nodecount(Union)<<endl;
	if(c=='y'||c=='Y')
	{
		size_t n=1;
		 printGraph(initialstate,n);
	}
	
	
}
/*----------------------InitVisit()------------------------*/
void MDGraph::InitVisit(Class_Of_State * S,size_t nb)
{
	//cout << "InitVisit function now called "<<endl;
	if(nb<=nbAggregates)
	{
		S->Visited=false;
		for(Edges::const_iterator i=S->Successors.begin();!(i==S->Successors.end());i++)
		{
				
				if((*i).first->Visited==true)
				{
					nb++;
					InitVisit((*i).first,nb);
				}
		}
		
	}
}
/*********                  printGraph    *****/
	
void MDGraph::printGraph(Class_Of_State *s,size_t &nb)
{
	//cout << "print graph function now is called "<<endl;
	if(nb<=nbAggregates)
	{
		cout<<"\nSTATE NUMBER "<< nb <<" : \n";
		cout<< "State root"<<bddtable<<s->class_state<<endl;
		//cout <<	s->class_state<<endl;
		s->Visited=true;
	 printsuccessors(s);
		getchar();
	printpredecessors(s);
		getchar();
		Edges::const_iterator i;
		for(i=s->Successors.begin();!(i==s->Successors.end());i++)
		{
			if((*i).first->Visited==false)
			{
				nb++;
				printGraph((*i).first, nb);
			}
		}
		
	}	  
			
}


/*---------void print_successors_class(Class_Of_State *)------------*/
void MDGraph::printsuccessors(Class_Of_State *s)
{
	Edges::const_iterator i;


    cout << " la classe  :  "<<s->class_state <<" \n";


	cout<< " on va affiche s-> classe of state "/*bddtable <<*/<<s->class_state<<endl;
//	if(s->boucle)
//		cout<<"\n\tON BOUCLE DESSUS AVEC EPSILON\n";
//	if(s->blocage)
//		cout<<"\n\tEXISTENCE D'UN ETAT BLOCANT\n";
	cout<<"\n\tSES SUCCESSEURS SONT  ( "<<s->Successors.size()<<" ) : \n\n"<<endl;// g changé
	//getchar();
	for(i =s->Successors.begin();!(i==s->Successors.end());i++)
	{
		cout<<" \t- t"<<(*i).second<<" ->";
		cout<<bddtable<<(*i).first->class_state<<endl;
	//
		getchar();
	}
}
/*---------void printpredescessors(Class_Of_State *)------------*/
void MDGraph::printpredecessors(Class_Of_State *s)
{ 	//cout << "MDGraph::printprecedecessors function"<<endl;
	Edges::const_iterator i;
	cout<<"\n\tSES PREDESCESSEURS SONT  ( "<<s->Predecessors.size()<<" ) :\n\n";
	//getchar();
	for(i =s->Predecessors.begin();!(i==s->Predecessors.end());i++)
	{
		cout<<" \t- t"<<(*i).second<<" ->";
		cout<<bddtable<<(*i).first->class_state<<endl;
		getchar();
	}
}

