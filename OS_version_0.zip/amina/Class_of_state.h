#ifndef CLASS_OF_STATE
#define CLASS_OF_STATE
#include "bdd.h"
#include <map>
#include <set>
#include <vector>
#include <utility>
#include <ext/hash_map>
using namespace std;
typedef set<int> Set;
class Class_Of_State
{
	public:
		Class_Of_State(){boucle=blocage=Visited=0;}
		Set firable;
		//Set Marked; // un set pour mettre les marked places
		bdd class_state;
		bool boucle;
		bool blocage;
		bool Visited;
		void * Class_Appartenance;
		vector<std::pair<Class_Of_State*,int> > Predecessors, Successors;
		std::pair<Class_Of_State*,int>  LastEdge;
};
typedef pair<Class_Of_State*, int> Edge;
typedef vector<Edge> Edges;
#endif
