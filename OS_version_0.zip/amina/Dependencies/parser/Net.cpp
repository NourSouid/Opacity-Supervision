#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <vector>
#include <map>
#include <ext/hash_map>
#include <algorithm>
#include "Net.h"
#define TAILLEBUFF 16384
/***********************************************************/
/*                      class Node                         */
/***********************************************************/

void  Node::addPre(int node,int valuation){
  pair<int,int> x(node,valuation);


  pre.push_back(x);
}

void Node::addPost(int node,int valuation){
  pair<int,int> x(node,valuation);
  post.push_back(x);
}

void  Node::addInhibitor(int node,int valuation){
  pair<int,int> x(node,valuation);
  inhibitor.push_back(x);
}

void  Node::addPreAuto(int node,int valuation){
  pair<int,int> x(node,valuation);
  preAuto.push_back(x);
}

void Node::addPostAuto(int node,int valuation){
  pair<int,int> x(node,valuation);
  postAuto.push_back(x);
}

void Node::addReset(int node){
  reset.push_back(node);
}

/***********************************************************/
/*                      class RdPE                         */
/***********************************************************/
net::net(const char *f,const char*Formula_trans, const char* Formula_Secret, const char* Formula_Secret1)
{//Formula_trans is Obs??--yes
	// cout<<"Formula_trans:"<<Formula_trans<<endl;
  //cout<<"CREATION D'UN NOUVEAU SOUS-RESEAU \n";
	//createXML fills out trans, places in R.
	  if(createXML(f) ){
		 // cout<<"createXML---> construire reseau \n"<<endl;//added by me
		 addPP(f);
    for (vector<class Place>::iterator p=places.begin();p!=places.end();p++){
    	//cout<<"I went in pla \n";
      sort(p->pre.begin(),p->pre.end());
      sort(p->post.begin(),p->post.end());
    }
    for (vector<class Transition>::iterator p=transitions.begin();p!=transitions.end();p++){
    	//cout<<"I went in trans \n";
      sort(p->pre.begin(),p->pre.end());
      sort(p->post.begin(),p->post.end());
    }
  }
  else{
	 // cout<<"clearing everything \n"<<endl;//added by me
    places.clear();
    transitions.clear();
    placeName.clear();
    transitionName.clear();
  }
	 // cout<<"Formula_trans length"<<strlen(Formula_trans)<<endl;
 if(strlen(Formula_trans)> 0)
  {
      //  cout<<"transitions de la formule non vide \n"; //comment
    Set_Formula_Trans(Formula_trans);//returns boolean
    if( strlen(Formula_Secret)>0) //
    {
    int i = 0;
    while(remainingLines(Formula_Secret)>=2){
    	//cout<<"before sys!"<<endl;//added by me
    //Secrets=
    Sys[i] = Set_Secrets(Formula_Secret);//sys gets s from set_secrets

    SkipTwoLines(Formula_Secret);
    i++;
   // cout<<"after sys!"<<endl; //added by me
    }
      //cout<<"transitions de l'interface non vide \n";
    }
    if( strlen(Formula_Secret1)>0){
    	readOpacityChoice(Formula_Secret1);
    }

    //cout<<"______________66666666666666666666666______________________\n";
    set_union(InterfaceTrans.begin(), InterfaceTrans.end(),Formula_Trans.begin(),Formula_Trans.end(), inserter(Observable, Observable.begin()));
      Set_Non_Observables();
  }
  else
	  for(unsigned int i=0;i<transitions.size();i++)
		  Observable.insert(i);
//cout<<"FIN CREATION \n";
}
/*---------------------------------Init Set of  transitions ------------------------------*/
/*---------------------------------Set_formula_trans()------------------*/
void net::readOpacityChoice(const char *f)
{
	//cout<<"opacity choice reading \n"<<endl; //added by me
	ifstream fichier(f, ios::in);  // on ouvre en lecture

	        if(fichier)  // si l'ouverture a fonctionné
	        {

	        	string opacity;  // déclaration d'une chaîne qui contiendra la ligne lue
	        	string knumber;
	                getline(fichier, opacity);  // on met dans "contenu" la ligne
	                OpacityChoce=atoi(opacity.c_str()) ; // on affiche la ligne
	                try{
	                	getline(fichier,knumber);
	                	K_step=atoi(knumber.c_str());
	                }catch (int e){
	                	cout<<e;
	                }
	                fichier.close();
	        }
	        else
	        {
	        	cerr << "cannot open file opacity choice !" << endl;
	        }

}
//----------------Set_Formula_Trans---------------------
bool net::Set_Formula_Trans(const char * f) 
{
	//cout<<"Set_Formula_Trans \n"<<endl; //added by me
	FILE *in;
	int i,nb;
		//cout<<"ici set formula transitions \n";
	int pos_trans (TRANSITIONS, string);
	char Buff[TAILLEBUFF], *z;
	in = fopen(f,"r");
	if (in == NULL)
	{
		cout << "file " << f << " doesn't exist" << endl;
		exit(1);
	}
	int nb_formula_trans;
	fscanf(in,"%d\n",&nb_formula_trans);
  	nb = fread(Buff,1,TAILLEBUFF-1,in);
  	Buff[nb] = '\0';
	z = strtok(Buff, " \t\n");
	//cout<<"taille "<<TAILLEBUFF<<" buff "<<Buff<<" z: "<<z<<endl;
	//cout<<nb_formula_trans<<endl;
	for(i= 0;i<nb_formula_trans;i++)
	{
		//cout<<" z: "<<z<<endl;
		if(z == NULL)
		{
			cout << "error in formula trans format "<< endl;
			return false;
	  	}
		string tmp(z);
		int pos=pos_trans(transitions,tmp);

		if(pos==-1)
		{      		  
		    cout<<z<<"    Error??? : observale transition "<<tmp<<" doesn't exist \n";
		    //return false;		  
		}
		else{
		//	cout<<" pos of observable transition: "<<z<<endl;
		  Formula_Trans.insert(pos);}
		//cout<<"insertion de :"<<transitions[pos].name<<endl;
		z = strtok(NULL, " \t\n");
		if (z == NULL)
		{
  			nb = fread(Buff,1,TAILLEBUFF-1,in);
  			Buff[nb] = '\0';
			z = strtok(Buff, " \t\n");
		}
	}
	fclose(in);
	return true;
}
/*---------------------------------Set_Secrets--------------------------*/
Set net::Set_Secrets(const char * f)
{
	//cout<<"Set_Secrets \n"<<endl; //added by me
	Set S ;
	//mettre les places secrets dans un set
	FILE *in;
	int i,nb;
	int pos_Secret (PLACES, string);
	char Buff[TAILLEBUFF],* z;
	in = fopen(f,"r");
	if (in == NULL)
	{
		cout << "file " << f << " doesn't exist" << endl;
		exit(1);
	}
	//cout << "file " << f << endl;
	int lineNumb=0;
	int int_Secret;
	fscanf(in,"%d\n",&int_Secret);
	lineNumb++;
	//cout<<"number of secretes in this line: "<<int_Secret<<endl;//commented
  	nb = fread(Buff,1,TAILLEBUFF-1,in);
  	Buff[nb] = '\0';
	z = strtok(Buff, " \t\n");
	lineNumb++;
	//cout<<"taille "<<TAILLEBUFF<<" buff "<<Buff<<" z: "<<z<<endl; //commented
	for(i= 0;i<int_Secret;i++)
	{
	//cout<<" z before loop: "<<z<<endl;//added by me
		if(z == NULL)
		{
			cout << "error in interface format "<< endl;

			//return;
	  	}
		string tmp(z);
		int pos=pos_Secret(places,tmp);
		//if(Formula_Trans.find(pos)==Formula_Trans.end())
		if(pos==-1)
		{
			cout<<"Line "<<lineNumb<<z<<"         Error??? : interface transition doesn't exist \n";
		//	return false;
		}
		else
			S.insert(pos);
	//	cout<<pos<<endl;
		z = strtok(NULL, " \t\n");
		if (z == NULL)
		{
		//	cout<<"insertion de :"<<places[pos].name<<endl;
  			nb = fread(Buff,1,TAILLEBUFF-1,in);
  			Buff[nb] = '\0';
			z = strtok(Buff, " \t\n");
		}
		//cout<<"z after loop: "<<z<<endl;//added by me
	}
	fclose(in);
	return S;
}
int net::remainingLines(const char *f)
{
	FILE* myfile = fopen(f, "r");
	int ch, number_of_lines = 0;

	do
	{
	    ch = fgetc(myfile);
	    if(ch == '\n')
	    	number_of_lines++;
	} while (ch != EOF);

	// last line doesn't end with a new line!
	// but there has to be a line at least before the last line
	if(ch != '\n' && number_of_lines != 0)
	    number_of_lines++;

	fclose(myfile);
	return number_of_lines;
}
void net::SkipTwoLines(const char *f){

		string line = "";
			// open input file
			ifstream inst(f);
			if( !inst.is_open())
			{
			cout << "Input file failed to open\n";
			}
			// now open temp output file
			ofstream out("outfile.txt");
			// loop to read/write the file. Note that you need to add code here to check
			// if you want to write the line
			int a = 0;
			while( getline(inst,line) )
			{
				if(a<2)
					a++;
				else
					out << line << "\n";
			}
			inst.close();
			out.close();
			// delete the original file

			remove(f);
			// rename old to new
			rename("outfile.txt",f);//What is the point of this one?? Where is it??
}
/*---------------------------------Set_Interface_trans()------------------*/ //?????


bool net::Set_Interface_Trans(const char * f)
{
	cout<<"Set_Interface_Trans \n"<<endl; //added by me
	FILE *in;
	int i,nb;
	int pos_trans (TRANSITIONS, string);
	char Buff[TAILLEBUFF],* z;
	in = fopen(f,"r");
	if (in == NULL)
	{
		cout << "file " << f << " doesn't exist" << endl;
		exit(1);
	}
	int int_trans;
	fscanf(in,"%d\n",&int_trans);
  	nb = fread(Buff,1,TAILLEBUFF-1,in);
  	Buff[nb] = '\0';
	z = strtok(Buff, " \t\n");
	//cout<<"taille "<<TAILLEBUFF<<" buff "<<Buff<<" z: "<<z<<endl;
	for(i= 0;i<int_trans;i++)
	{
	//cout<<" z: "<<z<<endl;
		if(z == NULL)
		{
			cout << "error in interface format "<< endl;
			return false;
	  	}
		string tmp(z);
		int pos=pos_trans(transitions,tmp);
		//if(Formula_Trans.find(pos)==Formula_Trans.end())
		if(pos==-1)
		{
			cout<<z<<"         Error??? : interface transition doesn't exist \n";
		//	return false;
		}
		else{
			cout<<"pos interfacetrans: "<<pos<<endl;
		  InterfaceTrans.insert(pos);}
		z = strtok(NULL, " \t\n");
		if (z == NULL)
		{
  			nb = fread(Buff,1,TAILLEBUFF-1,in);
  			Buff[nb] = '\0';
			z = strtok(Buff, " \t\n");
		}
	}
	fclose(in);
	return true;
}

/*---------------------------------Set_Non_Observables()------------------*/

void net::Set_Non_Observables() 
{
	//cout<<"Set_Non_Observables \n"<<endl; //added by me
	NonObservable.clear();
	for(unsigned int i=0;i<transitions.size();i++)
		if(Observable.find(i)==Observable.end())
		{
			//cout<<"non observable"<<i<<endl;
			NonObservable.insert(i);
		}
}
/*-----------------------pos-Secret()--------------------*/
int pos_Secret ( PLACES P, string pla)
{
	//cout<<"pos_Secret \n"<<endl; //added by me
	// Reperer les positions des secrets .
	int pos=0;
	//	cout<<"on cherche "<<trans<<" dans :\n";
	for(PLACES::const_iterator i=P.begin();!(i==P.end());i++,pos++)
	  {

	    if(i->name==pla){
	    //	cout<<i->name<<"   ";
	    	return pos;
	    }

	      }
	//cout<<"Non trouve :\n";
	return -1;
}


/*-----------------------pos_trans()--------------------*/
int pos_trans(TRANSITIONS T, string trans)
{
	//cout<<"pos_Secret \n"<<endl; //added by me
	int pos=0;
	//	cout<<"on cherche "<<trans<<" dans :\n";
	for(TRANSITIONS::const_iterator i=T.begin();!(i==T.end());i++,pos++)
	  {
	    //  cout<<i->name<<"   ";
	    if(i->name==trans)
			return pos;
	      }
	//cout<<"Non trouve :\n";
	return -1;
}
/* ------------------------------ operator<< -------------------------------- */
ostream& operator<<(ostream& os, const Set& s)
{
	//cout<<"operator \n"<<endl; //added by me
	bool b = false;
	
	if (s.size())
	{
		for (Set::const_iterator i=s.begin(); !(i==s.end()); i++)
		{
			if (b) 
				os << ", ";
			else
				os << "{";
			os  << *i<<" ";
			b = true;
		}
		os << "}";
	}
	else
		os << "empty set";
	return os;
		
}
/*----------------------------------------------------------------------*/


bool net::addPlace(const string &place,int marking,int capacity){
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end())
  {
    placeName[place]=places.size();
    Place p(place,marking, capacity);
    places.push_back(p);
    return true;
  }
  else
    return false;
}

bool net::addQueue(const string &place,int capacity){
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end())
  {
    placeName[place]=places.size();
    Place p(place,-1, capacity);
    places.push_back(p);
    return true;
  }
  else
    return false;
}

bool net::addLossQueue(const string &place,int capacity){
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end())
  {
    placeName[place]=places.size();
    Place p(place,-2, capacity);
    places.push_back(p);
    return true;
  }
  else
    return false;
}

bool net::addTrans(const string &trans){
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
  {
    transitionName[trans]=transitions.size();
    Transition t(trans);
    transitions.push_back(t);
    return true;
  }
  else
    return false;
}

bool net::addPre(const string &place,const string &trans,int valuation){
	//cout<<"place inputed: "<<place<<" transition inputed: "<<trans<<endl;
  int p,t;
  map<string,int>::const_iterator pi=placeName.find(place);
 // cout<<"pi 1st: "<<pi->first<<"pi 2nd: "<<pi->second<<endl;
  if(pi==placeName.end() || places[pi->second].isQueue())
    return false;
  else
    {
	  p=pi->second;
	//  cout<<"I added pre place! \n";
    }
  map<string,int>::const_iterator ti=transitionName.find(trans);
  //cout<<"ti 1st: "<<ti->first<<"ti 2nd: "<<ti->second<<endl;
  if(ti==transitionName.end())
    return false;
  else{
	  t=ti->second;
	//  cout<<"I added pre transition! \n";
  }

  transitions[t].addPre(p,valuation);
  //cout<<"about to add pre of"<<p<<" and it is: "<<valuation<<endl;
  places[p].addPost(t,valuation);
  return true;
}

bool net::addPost(const string &place,const string &trans,int valuation){
  int p,t;
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end() || places[pi->second].isQueue())
    return false;
  else
    p=pi->second;
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
    return false;
  else
    t=ti->second;
  transitions[t].addPost(p,valuation);
  places[p].addPre(t,valuation);
  return true;
}

bool net::addPreQueue(const string &place,const string &trans,int valuation){
  int p,t;
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end() || !places[pi->second].isQueue())
    return false;
  else
    p=pi->second;
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
    return false;
  else
    t=ti->second;
  transitions[t].addPre(p,valuation);
  places[p].addPost(t,valuation);
  return true;
}

bool net::addPostQueue(const string &place,const string &trans,int valuation){
  int p,t;
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end() || !places[pi->second].isQueue())
    return false;
  else
    p=pi->second;
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
    return false;
  else
    t=ti->second;
  transitions[t].addPost(p,valuation);
  places[p].addPre(t,valuation);
  return true;
}

bool net::addInhibitor(const string &place,const string &trans,int valuation){
  int p,t;
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end())
    return false;
  else
    p=pi->second;
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
    return false;
  else
    t=ti->second;
  transitions[t].addInhibitor(p,valuation);
  places[p].addInhibitor(t,valuation);
  return true;
}

bool net::addPreAuto(const string &place,const string &trans,const string &valuation){
  int p,t,v;
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end() || places[pi->second].isQueue())
    return false;
  else
    p=pi->second;
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
    return false;
  else
    t=ti->second;
  map<string,int>::const_iterator pv=placeName.find(valuation);
  if(pv==placeName.end() || places[pv->second].isQueue())
    return false;
  else
    v=pv->second;
  transitions[t].addPreAuto(p,v);
  places[p].addPostAuto(t,v);
  return true;
}

bool net::addPostAuto(const string &place,const string &trans,const string &valuation){
  int p,t,v;
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end() || places[pi->second].isQueue())
    return false;
  else
    p=pi->second;
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
    return false;
  else
    t=ti->second;
  map<string,int>::const_iterator pv=placeName.find(valuation);
  if(pv==placeName.end() || places[pi->second].isQueue())
    return false;
  else
    v=pv->second;
  transitions[t].addPostAuto(p,v);
  places[p].addPreAuto(t,v);
  return true;
}

bool net::addReset(const string &place,const string &trans){
  int p,t;
  map<string,int>::const_iterator pi=placeName.find(place);
  if(pi==placeName.end())
    return false;
  else
    p=pi->second;
  map<string,int>::const_iterator ti=transitionName.find(trans);
  if(ti==transitionName.end())
    return false;
  else
    t=ti->second;
  transitions[t].addReset(p);
  places[p].addReset(t);
  return true;
}

/* Visualisation */
ostream& operator<<(ostream &os,const net &R){

  os<<"affichage nombre de places et de transitions" <<endl;
  os<<"***************************"<<endl;
  os<<"Nombre de places     :"<<R.nbPlace()<<endl;
  os<<"Nombre de transitions:"<<R.nbTransition()<<endl;

/* affichage de la liste des places */
  os<<"********** places **********"<<endl;
  int i=0;
  for (vector<class Place>::const_iterator p=R.places.begin();p!=R.places.end();p++,i++){
    if (p->isQueue()) {
       	os<<"queue hahaha net.cpp " << setw(4)<<i<<":"<<p->name<<", cp("<<p->capacity<<")";
		if (p->isLossQueue())
			cout << " loss"; 
		cout << endl;
	}
	else
    	os<<"place " << setw(4)<<i<<":"<<p->name<<":"<<p->marking<<" <..>, cp(" << p->capacity<<")"<<endl;
  }
 os<<"********** transitions  de la formule  **********"<<endl;
  for(Set::const_iterator h=R.Formula_Trans.begin();!(h==R.Formula_Trans.end());h++)
	  cout<<R.transitions[*h].name<<endl;
  os<<"********** transitions  de l'interface  **********"<<endl;
  for(Set::const_iterator h=R.InterfaceTrans.begin();!(h==R.InterfaceTrans.end());h++)
	  cout<<R.transitions[*h].name<<endl;
  os<<"Nombre de transitions observable:"<<R.Observable.size()<<endl;
  os<<"********** transitions observables **********"<<endl;
  for(Set::const_iterator h=R.Observable.begin();!(h==R.Observable.end());h++)
	  cout<<R.transitions[*h].name<<endl;
	    os<<"Nombre de transitions non observees:"<<R.NonObservable.size()<<endl;
  os<<"********** transitions  non observees **********"<<endl;
  for(Set::const_iterator h=R.NonObservable.begin();!(h==R.NonObservable.end());h++)
	  cout<<R.transitions[*h].name<<endl; 
  i=0;
   os<<"Nombre global de transitions :"<<R.nbTransition()<<endl;
  os<<"********** transitions  **********"<<endl;
  for (TRANSITIONS::const_iterator t=R.transitions.begin();t!=R.transitions.end();t++,i++)
{
    os<<setw(4)<<i<<":"<<t->name<<endl;
  
//comented part 2 I deleted
  }
  return(os);
}
