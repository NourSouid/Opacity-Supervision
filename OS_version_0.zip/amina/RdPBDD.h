/* -*- C++ -*- */
#ifndef RdPBDD_H
#define RdPBDD_H
#include <vector>
#include <stack>
#include <utility>
#include <stdio.h>
#include <iostream>
#include "Net.h"
#include "bdd.h"
#include"MDGraph.h"
#include"Modular_Obs_Graph.h"
#include "Modular_Class_of_state.h"
using namespace std;
//#include"Modular_Obs_Graph.hpp"
/***********************************************/
class Trans {
public:
	Trans(const bdd& var, bddPair* pair, const bdd& rel,const bdd& prerel,const bdd& Precond, const bdd& Postcond);
	bdd operator()(const bdd& op) const;//Franchissement avant
	bdd operator[](const bdd& op) const;//Franchissement arrière
  friend class RdPBDD;

private:
	bdd var;
	bddPair* pair;
    bdd Precond;
    bdd Postcond;
	bdd rel;
    bdd prerel;

};

class RdPBDD {
private :
  vector<class Transition> transitions;
  Set Observable;
  Set Secret[16384] ;
  Set NonObservable;
  map<string,int> transitionName;
  map<string,int> placeName;// j'ai ajouter placename map;
  Set InterfaceTrans;
  Set Formula_Trans;
  unsigned int Nb_places;
public:
  int OpacityChoice;
  int K_Step;
  bdd M0;
  bdd Secretb;
  bdd SecretBdd;
  bdd T;
  bdd cross;
  bdd currentvar;
  vector<Trans> relation;
  vector<Place> places ;
  bdd ReachableBDD1();
 // Set Set_Marked(bdd state);
  bdd ReachableBDD2();
  bdd ReachableBDD3();
  bdd VerifiParent(bdd s,int f);


//  Set GetMarked(std::vector<string> s);
  bool FindSbVector(vector<string> a , string c );
  bdd GetPrerel(bdd s , int t);
  string GetFather(bdd d);
/* G�n�ration de graphes d'observation */
void compute_canonical_deterministic_graph_Opt(MDGraph& g) ;
  bdd Accessible_epsilon(bdd From);
  //quantified opacity Saturate function
  bdd QSaturate(bdd From, bool init);
  bdd Accessible_epsilon_quantified(bdd From);//quantified
  bdd Accessible_epsilon2(bdd From);
  bdd StepForward(bdd From);
 // bdd get_Precedor(bdd From,int t);
  bdd StepBackward3(bdd From , int i);
  bdd VerificationPost(int t);
  int weakOpacity(bdd state,bdd secret , int numStatCros);
  int StrongOpacity(bdd state , bdd secret ,int numStatCros);
  bdd StepForward2(bdd From);
  bdd StepBackward(bdd From);
  //Set Set_Marked(bdd S);
  string ConvertToString (bdd S);
  bdd StepBackward2(bdd From);
  std::vector<string> Tokenizer(string s);
  bdd EmersonLey(bdd S, bool trace);
  Set GetSetMarked(std::vector<string> Vec_Ma) ;
  Set firable_obs(bdd State);
  bdd get_successor(bdd From,int t);
  void GeneralizedSynchProduct1(Modular_Obs_Graph& Gv, int NbSubnets,RdPBDD* Subnets[] ,int nbbddvar) ;
  bool Set_Div(bdd &S) const;
  bool Set_Bloc(bdd &S) const;
  bool SimpleOpacityVerifer(Set A ,Set B , bdd c );
  bdd FrontiereNodes(bdd From) const ;
  bdd CanonizeR(bdd s, unsigned int i) ;
  RdPBDD(const net&,int BOUND=32,bool init=false);
  ~RdPBDD(){};
};
/*____________Structure utiles aux produit synchronis� g�n�ralis� de n graphes d'observations ________*/

/*typedef pair<Modular_Class_Of_State*,bdd*> CoupleNodes; // M�ta-�tat (canonis�) + vecteur des bdds complets
typedef pair<Set*,Set*> CoupleSets;//ens d'ens des trans de la formule franchissables non encore trait�es + ens d'ens des trans de l'interface franchissables non encore trait�es
typedef pair<CoupleNodes,CoupleSets> PairProduct; // Couple + ens des ens des transitions franchissables non encore trait�es
typedef pair<PairProduct,bool> StackElt;
typedef vector<StackElt> Stack;*/
typedef pair<Modular_Class_Of_State*,bdd*> Couple;
typedef pair<Couple,Set*> StackElt;
typedef stack<StackElt> Stack;
typedef vector<StackElt> PileInt;
typedef pair<StackElt,PileInt> CanonicRep;
//typedef stack<CanonicRep> STACK;
typedef stack<PileInt> STACK;
int InStack(PileInt,Modular_Class_Of_State*);
bool MemeVecteur(vector<bdd>,vector<bdd>);
bool Inferieur(vector<bdd>,vector<bdd>);

#endif
